/* Automatically generated from Squeak on #(31 March 2005 3:48:20 pm) */

#define SQ_VI_BYTES_PER_WORD 8
