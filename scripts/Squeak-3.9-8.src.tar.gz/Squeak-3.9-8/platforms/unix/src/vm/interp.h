/* Automatically generated from Squeak on an Array(23 April 2006 10:01:07 pm) */

#define SQ_VI_BYTES_PER_WORD 4
