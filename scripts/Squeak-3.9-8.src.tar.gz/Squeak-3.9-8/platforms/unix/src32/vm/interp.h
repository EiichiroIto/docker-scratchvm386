/* Automatically generated from Squeak on #(31 March 2005 3:46:52 pm) */

#define SQ_VI_BYTES_PER_WORD 4
