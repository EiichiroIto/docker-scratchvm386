#if defined(macintoshSqueak)
#include "sqMacPrinting.h"
#else
#include "sqPrinting.h"
#endif
