#include "ieee754names.h"
#include "fdlibm/e_log10.c"
