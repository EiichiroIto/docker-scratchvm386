#ifndef MPEG3CSS_H
#define MPEG3CSS_H


#include "mpeg3private.inc"

struct mpeg3_block 
{
    char    huh;
};

struct mpeg3_playkey {
    char    huh;
};

typedef struct
{
    char    huh;
} mpeg3_css_t;

#endif
