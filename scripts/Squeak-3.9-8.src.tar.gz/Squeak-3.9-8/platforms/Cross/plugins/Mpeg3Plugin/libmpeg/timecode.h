#ifndef TIMECODE_H
#define TIMECODE_H

typedef struct 
{
	long hour;
	long minute;
	long second;
	long frame;
} mpeg3_timecode_t;

#endif
